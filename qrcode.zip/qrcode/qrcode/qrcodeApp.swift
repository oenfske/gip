//
//  qrcodeApp.swift
//  qrcode
//
//  Created by Lenny on 11/02/2022.
//

import SwiftUI

@main
struct qrcodeApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
